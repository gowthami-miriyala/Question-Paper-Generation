from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('questions/', views.question_list, name='question_list'),
    path('questions/add/', views.question_add, name='question_add'),
    path('questions/<int:pk>/edit/', views.question_edit, name='question_edit'),
    path('questions/<int:pk>/delete/', views.question_delete, name='question_delete'),
    path('generate/', views.generate_paper, name='generate_paper'),
    path('paper/<int:pk>/', views.paper_detail, name='paper_detail'),
    path('paper/<int:pk>/pdf/', views.download_pdf, name='download_pdf'),
    path('papers/', views.paper_history, name='paper_history'),
]
