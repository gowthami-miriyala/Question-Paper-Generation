import random

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.template.loader import get_template
from django.http import HttpResponse
from xhtml2pdf import pisa

from .models import Subject, Unit, Question, QuestionPaper, QuestionPaperItem
from .forms import QuestionForm


@login_required
def dashboard(request):
    context = {
        'total_questions': Question.objects.count(),
        'total_papers': QuestionPaper.objects.count(),
        'total_subjects': Subject.objects.count(),
    }
    return render(request, 'questions/dashboard.html', context)


@login_required
def question_list(request):
    questions = Question.objects.all().order_by('-created_at')
    subject_id = request.GET.get('subject')
    if subject_id:
        questions = questions.filter(subject_id=subject_id)
    subjects = Subject.objects.all()
    return render(request, 'questions/question_list.html', {
        'questions': questions, 'subjects': subjects
    })


@login_required
def question_add(request):
    if request.method == 'POST':
        form = QuestionForm(request.POST)
        if form.is_valid():
            q = form.save(commit=False)
            q.created_by = request.user
            q.save()
            messages.success(request, 'Question added successfully.')
            return redirect('question_list')
    else:
        form = QuestionForm()
    return render(request, 'questions/question_form.html', {'form': form})


@login_required
def question_edit(request, pk):
    question = get_object_or_404(Question, pk=pk)
    if request.method == 'POST':
        form = QuestionForm(request.POST, instance=question)
        if form.is_valid():
            form.save()
            messages.success(request, 'Question updated.')
            return redirect('question_list')
    else:
        form = QuestionForm(instance=question)
    return render(request, 'questions/question_form.html', {'form': form})


@login_required
def question_delete(request, pk):
    question = get_object_or_404(Question, pk=pk)
    if request.method == 'POST':
        question.delete()
        messages.success(request, 'Question deleted.')
        return redirect('question_list')
    return render(request, 'questions/question_confirm_delete.html', {'question': question})


@login_required
def generate_paper(request):
    subjects = Subject.objects.all()
    if request.method == 'POST':
        subject_id = request.POST.get('subject')
        title = request.POST.get('title')
        marks_2 = int(request.POST.get('marks_2', 0) or 0)
        marks_5 = int(request.POST.get('marks_5', 0) or 0)
        marks_10 = int(request.POST.get('marks_10', 0) or 0)

        subject = get_object_or_404(Subject, pk=subject_id)
        distribution = {2: marks_2, 5: marks_5, 10: marks_10}

        selected_questions = []
        for marks, count in distribution.items():
            if count > 0:
                pool = list(Question.objects.filter(subject=subject, marks=marks))
                chosen = random.sample(pool, min(count, len(pool)))
                selected_questions.extend(chosen)

        if not selected_questions:
            messages.error(request, 'No questions found matching that criteria.')
            return redirect('generate_paper')

        total_marks = sum(q.marks for q in selected_questions)
        paper = QuestionPaper.objects.create(
            title=title, subject=subject, total_marks=total_marks, created_by=request.user
        )
        for i, q in enumerate(selected_questions, start=1):
            QuestionPaperItem.objects.create(paper=paper, question=q, question_number=i)

        messages.success(request, 'Paper generated successfully!')
        return redirect('paper_detail', pk=paper.pk)

    return render(request, 'questions/generate_paper.html', {'subjects': subjects})


@login_required
def paper_detail(request, pk):
    paper = get_object_or_404(QuestionPaper, pk=pk)
    items = paper.items.all()
    return render(request, 'questions/paper_detail.html', {'paper': paper, 'items': items})


@login_required
def paper_history(request):
    papers = QuestionPaper.objects.all().order_by('-created_at')
    return render(request, 'questions/paper_history.html', {'papers': papers})


@login_required
def download_pdf(request, pk):
    paper = get_object_or_404(QuestionPaper, pk=pk)
    items = paper.items.all()
    template = get_template('questions/paper_pdf.html')
    html = template.render({'paper': paper, 'items': items})

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{paper.title}.pdf"'
    pisa_status = pisa.CreatePDF(html, dest=response)

    if pisa_status.err:
        return HttpResponse('PDF generation error', status=500)
    return response
