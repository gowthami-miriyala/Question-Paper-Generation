from django.contrib import admin
from .models import Subject, Unit, Question, QuestionPaper, QuestionPaperItem

admin.site.register(Subject)
admin.site.register(Unit)
admin.site.register(Question)
admin.site.register(QuestionPaper)
admin.site.register(QuestionPaperItem)
