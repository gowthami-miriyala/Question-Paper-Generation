# Question Paper Generator — Ready-to-run Django project

This is the complete, working MVP: auth, question bank CRUD, paper generation,
and PDF export.

## IMPORTANT — where to put this folder

Unzip this **outside OneDrive** — e.g. into `C:\projects\qpg` — not into
`Desktop` or any OneDrive-synced folder. OneDrive sync can cause files to
behave inconsistently with Django's file-watching and caching.

## How to run

Open a terminal inside this unzipped folder and run, one line at a time:

```bash
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # macOS / Linux

pip install -r requirements.txt

python manage.py makemigrations questions
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Then open:
- `http://127.0.0.1:8000/admin/` — Django admin, add Subjects, Units, Questions here first
- `http://127.0.0.1:8000/login/` — your app's own login (same credentials)
- `http://127.0.0.1:8000/` — dashboard, once logged in

## If `makemigrations questions` says "No changes detected"

That means something is wrong before this point — stop and check:
1. `pip list` shows Django installed
2. You're running the command from inside this exact folder
3. No other Django project is on your PYTHONPATH

## Add test data quickly

Log into `/admin/` and add:
- 2 Subjects (e.g. "Data Structures", code `CS201`)
- 2–3 Units per subject
- 15–20 Questions spread across marks (2, 5, 10) and difficulty

Then go to `/generate/` to build a paper, and download it as a PDF from the
paper detail page.
